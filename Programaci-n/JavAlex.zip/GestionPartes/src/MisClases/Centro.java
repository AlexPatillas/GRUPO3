package MisClases;

public class Centro {
    private Integer id_centro;
    private String nombre;
    private Direccion direccion;
    private Integer telefono;

    public Centro(Integer codigo, String nombre, Direccion direccion, Integer telefono) {
        this.id_centro = id_centro;
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
    }

    public Centro() {
    }

    public Integer getId_centro() {
        return id_centro;
    }

    public void setId_centro(Integer id_centro) {
        this.id_centro = id_centro;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }

    public Integer getTelefono() {
        return telefono;
    }

    public void setTelefono(Integer telefono) {
        this.telefono = telefono;
    }

    
    
}
