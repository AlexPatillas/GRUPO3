package MisClases;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;



public class DireccionBD {
    private static GenericoBD gbd;
    
    public DireccionBD() {
    
    }
    
    public static ArrayList<Direccion> obtenerDirecciones() {
        ArrayList<Direccion> dir = new ArrayList();
        try {
            gbd = new GenericoBD();
            Statement sentencia = gbd.abrirConexion().createStatement();
            ResultSet resultado = sentencia.executeQuery("select * from direcciones");
            while (resultado.next()) {
                Direccion dire = new Direccion(resultado.getInt("id_dir"),resultado.getString("provincia"),resultado.getString("ciudad"),resultado.getString("calle"),resultado.getInt("numero"),resultado.getInt("piso"),resultado.getString("mano"),resultado.getInt("codigo_postal"));
                dir.add(dire);
            }
            gbd.cerrarConexion();
            return dir;
        } 
        catch (Exception e) {javax.swing.JOptionPane.showMessageDialog(null ,"Problemas en obtenerDirecciones " + e.getMessage());
            return dir;
        } 
    }
    
    public static Direccion obtenerDireccionId(int id) {
        Direccion dir = new Direccion();
        try {
            gbd = new GenericoBD();
            Statement sentencia = gbd.abrirConexion().createStatement();
            ResultSet resultado = sentencia.executeQuery("select * from direcciones where id_dir='"+id+"'");
            while (resultado.next()) {
                dir = new Direccion(resultado.getInt("id_dir"),resultado.getString("provincia"),resultado.getString("ciudad"),resultado.getString("calle"),resultado.getInt("numero"),resultado.getInt("piso"),resultado.getString("mano"),resultado.getInt("codigo_postal"));
            }
            gbd.cerrarConexion();
            return dir;
        } 
        catch (Exception e) {javax.swing.JOptionPane.showMessageDialog(null ,"Problemas en obtenerDireccionId " + e.getMessage());
            return dir;
        } 
    }
    
    public static void registrarDireccionTrabajador(Direccion dir) {
        try {
            Statement sentencia = gbd.abrirConexion().createStatement();
            sentencia.executeUpdate("insert into direcciones values ("+dir.getId()+" '"+dir.getProvincia()+"' '"+dir.getCiudad()+"' '"+dir.getCalle()+"',"+dir.getNumero()+","+dir.getPiso()+",'"+dir.getMano()+"' "+dir.getCp()+")");
            gbd.cerrarConexion();
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null, "Problemas en registrarDireccionTrabajador "+e.getMessage());
        }
    }
}
