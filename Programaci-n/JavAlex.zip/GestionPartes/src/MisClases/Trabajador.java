package MisClases;

public class Trabajador {
    
    private String dni;
    private String nombre;
    private String apeuno;
    private String apedos;
    private Direccion direccion;
    private Integer telefonoPersonal;
    private Integer telefonoEmpresa;
    private Double salario;
    private String fechaNac;
    private String tipo;
    private Centro id_centro;

    public Trabajador(String dni, String nombre, String apeuno, String apedos, Direccion direccion, Integer telefonoPersonal, Integer telefonoEmpresa, Double salario, String fechaNac, String tipo, Centro id_centro) {
        this.dni = dni;
        this.nombre = nombre;
        this.apeuno = apeuno;
        this.apedos = apedos;
        this.direccion = direccion;
        this.telefonoPersonal = telefonoPersonal;
        this.telefonoEmpresa = telefonoEmpresa;
        this.salario = salario;
        this.fechaNac = fechaNac;
        this.tipo = tipo;
        this.id_centro = id_centro;
    }

    public Trabajador() {
    }

    public Trabajador(String d, String no, String aU, String aD, Integer id, String pr, String ci, String ca, Integer nu, Integer pi, String m, Integer cp, Integer tP, Integer tE, String s, String t, String f, Centro ic) {
    }

    public Trabajador(String d, String non, String aUn, String aDn, Integer idn, String prn, String cin, String can, Integer nun, Integer pin, String mn, Integer cpn, Integer tPn, Integer tEn, String sn, String tn, String fn, String icn) {
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Integer getTelefonoPersonal() {
        return telefonoPersonal;
    }

    public void setTelefonoPersonal(Integer telefonoPersonal) {
        this.telefonoPersonal = telefonoPersonal;
    }

    public Integer getTelefonoEmpresa() {
        return telefonoEmpresa;
    }

    public void setTelefonoEmpresa(Integer telefonoEmpresa) {
        this.telefonoEmpresa = telefonoEmpresa;
    }

    public Double getSalario() {
        return salario;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }

    public String getFechaNac() {
        return fechaNac;
    }

    public void setFechaNac(String fechaNac) {
        this.fechaNac = fechaNac;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Centro getId_centro() {
        return id_centro;
    }

    public void setId_centro(Centro id_centro) {
        this.id_centro = id_centro;
    }

    public String getApeuno() {
        return apeuno;
    }

    public void setApeuno(String apeuno) {
        this.apeuno = apeuno;
    }

    public String getApedos() {
        return apedos;
    }

    public void setApedos(String apedos) {
        this.apedos = apedos;
    }

    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }
    
    
}
