package MisClases;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class TrabajadorBD {
     private static GenericoBD gbd;

    public TrabajadorBD() {
        
    }
    
    public static void AltaTrabajador(Trabajador tra) {
        try {
            gbd = new GenericoBD();
            Statement sentencia = gbd.abrirConexion().createStatement();
            sentencia.executeUpdate("insert into trabajador values ('"+tra.getDni()+"','"+tra.getNombre()+"','"+tra.getApeuno()+"','"+tra.getApedos()+"',"+tra.getDireccion().getId()+","+tra.getTelefonoEmpresa()+","+tra.getTelefonoPersonal()+","+tra.getSalario()+",TO_DATE('"+tra.getFechaNac()+"','yyyy/mm/dd'),'"+tra.getTipo()+"',"+tra.getId_centro().getId_centro()+")");
          // Valores sacados de la *Base de datos*                 ('  12312312A     ','  Asier            ','  Suárez           ','  Ubierna          ',  01                          ,  945945945                 ,  688688688                  ,  2000.00           ,TO_DATE('  1997/01/01         ','yyyy/mm/dd'),'  administracion ',  01                           ) 
          // Hemos insertado un primer trabajador en la base de datos del tipo administración, para poder operar.
            LoginBD.crearLogin(tra.getNombre(), tra.getApeuno(), tra.getApedos(), tra.getDni());
            gbd.cerrarConexion();
        } 
        catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null ,"Problemas en logearUsuario " + e.getMessage());
        }
    
    }
    
    public static void BajaTrabajador(String dni) {
        try {
            gbd = new GenericoBD();
            Statement sentencia = gbd.abrirConexion().createStatement();
            sentencia.executeUpdate("delete from trabajador where lower(dni) = '"+dni+"'");
            gbd.cerrarConexion();
        }
        catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null ,"Problemas en eliminarTrabajador " + e.getMessage());
        }
    }
    
    
    public static ArrayList<Trabajador> listaTrabajadores() {
        try {
            ArrayList<Trabajador> lista = new ArrayList();
            gbd = new GenericoBD();
            Statement sentencia = gbd.abrirConexion().createStatement();
            ResultSet resultado = sentencia.executeQuery("select * from trabajador");
            while (resultado.next()) {
                Trabajador tra = new Trabajador(resultado.getString("dni"),resultado.getString("nombre"),resultado.getString("apellido1"),resultado.getString("apellido2"),DireccionBD.obtenerDireccionId(resultado.getInt("direccion")),resultado.getInt("tel_per"),resultado.getInt("tel_emp"),resultado.getDouble("Salario"),resultado.getString("fecha_nac"),resultado.getString("tipo"),CentroBD.buscarCentroPorId(resultado.getInt("Centro")));
                lista.add(tra);
            }
            return lista;
        }
        catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null ,"Problemas en listaTrabajadores " + e.getMessage());
        }
        return null;
    }
    
    public void ModificarTrabajador(Trabajador tv, Trabajador tn)throws Exception{
        String plantilla="update Trabajador set dni = ?, Apellido1 = ?, Apellido2 = ?, Direccion = ?, Tel_Emp = ?, Tel_Per = ?, Salario = ?, Fecha_Nac = ?, tipo = ?, id_Centro = ? where dni = ?;";
        PreparedStatement ps=gbd.abrirConexion().prepareStatement(plantilla);
        ps.setString(1,tn.getDni());
        ps.setString(2,tn.getNombre());
        ps.setString(3,tn.getApeuno());
        ps.setString(4,tn.getApedos());  
        ps.setInt(5, tn.getDireccion().getId());
        ps.setString(6,tn.getDireccion().getProvincia());
        ps.setString(7,tn.getDireccion().getCiudad());
        ps.setString(8,tn.getDireccion().getCalle());
        ps.setInt(9,tn.getDireccion().getNumero());
        ps.setInt(10,tn.getDireccion().getPiso());
        ps.setString(11,tn.getDireccion().getMano());
        ps.setInt(12,tn.getDireccion().getCp());
        ps.setInt(13,tn.getTelefonoPersonal());
        ps.setInt(14,tn.getTelefonoEmpresa());
        ps.setDouble(15,tn.getSalario());
        ps.setString(16,tn.getFechaNac());
        ps.setString(17,tn.getTipo());
        ps.setInt(18,tn.getId_centro().getId_centro());
        ps.setString(19,tn.getId_centro().getNombre());
        ps.setInt(20,tn.getId_centro().getDireccion().getId());
        ps.setString(21,tn.getId_centro().getDireccion().getProvincia());
        ps.setString(22,tn.getId_centro().getDireccion().getCiudad());
        ps.setString(23,tn.getId_centro().getDireccion().getCalle());
        ps.setInt(24,tn.getId_centro().getDireccion().getNumero());
        ps.setInt(25,tn.getId_centro().getDireccion().getPiso());
        ps.setString(26,tn.getId_centro().getDireccion().getMano());
        ps.setInt(27,tn.getId_centro().getDireccion().getCp());
        ps.setInt(28,tn.getId_centro().getTelefono());
        ps.setString(29,tv.getDni());
        int n = ps.executeUpdate();
        gbd.cerrarConexion();
        
        
    }
}
