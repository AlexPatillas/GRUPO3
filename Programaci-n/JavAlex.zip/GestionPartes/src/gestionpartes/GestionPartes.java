package gestionpartes;

import MisClases.*;
import MisExcepciones.VacioException;
import MisVentanas.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class GestionPartes {

    private static DModificar DModificar;
    private static DParte DParte;
    private static VentanaInicial v1;
    private static DLogin login;
    private static Trabajador trabajadorActual, tV, tN;  
    private static TrabajadorBD tbd;    
    
    public static void main(String[] args) {
        v1 = new VentanaInicial();
        v1.setVisible(true);
        login = new DLogin(v1,true);
        login.setVisible(true);
    }
    
    public static void login(String nombre, String contraseña) {
        String a = MisClases.LoginBD.logearUsuario(nombre, contraseña);
        if (a.equalsIgnoreCase("logistica")||a.equalsIgnoreCase("administracion")) {
            login.dispose();
            String b = MisClases.LoginBD.obtenerNombre(nombre, contraseña);
            JOptionPane.showMessageDialog(null, "Bienvenido, " +b);
            if (a.equalsIgnoreCase("logistica")){
                DParte = new DParte(v1,true);
                DParte.setVisible(true);
            }
            else {
                DModificar = new DModificar(v1, true);
                DModificar.setVisible(true);
            }
        }
        else {
            JOptionPane.showMessageDialog(null, a);
            login.CuentaErrores();
        }
    }
    
    public static void AltaTrabajador(String dni, String nombre, String apeUno, String apeDos, Direccion direccion, String provincia, String ciudad, String calle, int numero, int piso, String mano, int cp, Integer telefonoPersonal, Integer telefonoEmpresa, String salario, String tipo, String fecha, Centro id_centro) {
        if (salario.equals("")) {
            salario=null;
        }
        else {
            
        }
        if (telefonoPersonal.equals("")) {
            telefonoPersonal = null;
        }
        else {
            
        }
        Direccion dir = registrarDireccion(provincia, ciudad, calle, numero, piso, mano, cp);
        Centro cen = CentroBD.idPorNombre(nombre);
        try {
            if (cen==null)
                throw new VacioException("Error al reconocer el centro");
            JOptionPane.showMessageDialog(null, fecha);
            
            Trabajador tra = new Trabajador(dni,nombre,apeUno,apeDos,direccion,telefonoPersonal,telefonoEmpresa,Double.parseDouble(salario),fecha,tipo,id_centro);
            TrabajadorBD.AltaTrabajador(tra);
        }
        catch (VacioException e) {
            JOptionPane.showMessageDialog(null, VacioException.getMensaje());
        }
    }
    
    public static Direccion registrarDireccion(String provincia, String ciudad, String calle, Integer numero, Integer piso, String mano, Integer cp) {
        ArrayList<Direccion> dir = DireccionBD.obtenerDirecciones();
        boolean salir=false;
        int x=0;
        
        for (x=0;salir==false;x++) {
            for (int y=0;salir==false;y++) {
                if (x!=dir.get(y).getId())
                    salir=true;
            }
        }
        x=x-1;
        Direccion dire = new Direccion(x,provincia, ciudad, calle, numero, piso, mano, cp);
        DireccionBD.registrarDireccionTrabajador(dire);
        return dire;
    }
    
    public static void BajaTrabajador(String dni) {
        dni=dni.toLowerCase();
        TrabajadorBD.BajaTrabajador(dni);
    }
    
    public static ArrayList<String> nombreCentros() {
        ArrayList<String> nomCen = new ArrayList();
        ArrayList<Centro> cen = CentroBD.VisualizarListaCentros();
        for (int x=0;x<cen.size();x++) {
            nomCen.add(cen.get(x).getNombre());
        }
        return nomCen;
    }
    
    public static void modificar(String d, String no, String aU, String aD, Integer id, String pr, String ci, String ca, Integer nu, Integer pi, String m, Integer cp, Integer tP, Integer tE, String s, String t, String f, Centro ic,
                                 String dn, String non, String aUn, String aDn, Integer idn, String prn, String cin, String can, Integer nun, Integer pin, String mn, Integer cpn, Integer tPn, Integer tEn, String sn, String tn, String fn, String icn) throws Exception{
        tV = new Trabajador(d,no,aU,aD,id,pr,ci,ca,nu,pi,m,cp,tP,tE,s,t,f,ic);
        tN = new Trabajador(d,non,aUn,aDn,idn,prn,cin,can,nun,pin,mn,cpn,tPn,tEn,sn,tn,fn,icn);
        tbd.ModificarTrabajador(tV,tN);       
    }
    
    public static boolean mostrarDatosTrabajador(String dni) { 
        
        ArrayList<Trabajador> lista = TrabajadorBD.listaTrabajadores();
        boolean existe=false;
        for (int x=0;x<lista.size()||existe==false;x++) {
            if (dni.equalsIgnoreCase(lista.get(x).getDni())) {
                trabajadorActual = lista.get(x);
                existe=true;
            }
        }
        return existe;
    }
    
    public static Trabajador getTrabajadorActual() {
        return trabajadorActual;
    }
    
    public static void cerrarProyecto() {
        System.exit(0);
    }

    public static void AltaTrabajador(String text, String text0, String text1, String text2, String text3, String text4, String text5, String toString, String toString0, String text6, String toString1, String text7, String text8, String text9, String toString2, String a, String toString3) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
